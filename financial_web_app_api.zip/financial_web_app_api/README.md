# API de Gerenciamento Financeiro

Uma API RESTful para gerenciamento de finanças pessoais, construída com Node.js, Express e MySQL.

## Funcionalidades

- Gerenciamento de usuários com autenticação
- Gerenciamento de contas
- Acompanhamento de transações
- Gerenciamento de categorias
- Endpoints de API seguros com autenticação JWT
- Validação de dados e tratamento de erros

## Pré-requisitos

- Node.js (v14 ou superior)
- MySQL (v8 ou superior)
- npm ou yarn

## Configuração


1. Instale as dependências:
   ```
   npm install
   ```

2. Configure o MySQL:
   - Instale o MySQL Server em sua máquina
   - Crie um novo banco de dados e configure o schema:
     ```sql
     -- Criar o banco de dados
     CREATE DATABASE IF NOT EXISTS financial_app;
     USE financial_app;

     -- Tabela de Usuários
     CREATE TABLE IF NOT EXISTS Users (
         ID INT AUTO_INCREMENT PRIMARY KEY,
         Email VARCHAR(255) NOT NULL UNIQUE,
         Password VARCHAR(255) NOT NULL,
         Name VARCHAR(100),
         CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
         UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
     );

     -- Tabela de Categorias
     CREATE TABLE IF NOT EXISTS Categories (
         ID INT AUTO_INCREMENT PRIMARY KEY,
         UserId INT NOT NULL,
         Name VARCHAR(100) NOT NULL,
         CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
         UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         FOREIGN KEY (UserId) REFERENCES Users(ID) ON DELETE CASCADE,
         CONSTRAINT unique_category_per_user UNIQUE (UserId, Name)
     );

     -- Tabela de Contas
     CREATE TABLE IF NOT EXISTS Accounts (
         ID INT AUTO_INCREMENT PRIMARY KEY,
         UserId INT NOT NULL,
         Account_Name VARCHAR(255) NOT NULL,
         Initial_Amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
         CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
         UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         FOREIGN KEY (UserId) REFERENCES Users(ID) ON DELETE CASCADE,
         CONSTRAINT unique_account_name_per_user UNIQUE (UserId, Account_Name)
     );

     -- Tabela de Transações
     CREATE TABLE IF NOT EXISTS Transactions (
         ID INT AUTO_INCREMENT PRIMARY KEY,
         AccountID INT NOT NULL,
         CategoryID INT,
         Value DECIMAL(10, 2) NOT NULL,
         Type ENUM('income', 'expense') NOT NULL,
         Date DATE NOT NULL,
         Description TEXT,
         CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
         UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         FOREIGN KEY (AccountID) REFERENCES Accounts(ID) ON DELETE CASCADE,
         FOREIGN KEY (CategoryID) REFERENCES Categories(ID) ON DELETE SET NULL
     );
     ```

   - Crie um usuário MySQL :
     ```sql
     CREATE USER 'your_mysql_user'@'localhost' IDENTIFIED BY 'your_mysql_password';
     GRANT ALL PRIVILEGES ON financial_app.* TO 'your_mysql_user'@'localhost';
     FLUSH PRIVILEGES;
     ```
   - Anote as credenciais criadas para usar no próximo passo
   
   > **Nota**: O schema contém todas as tabelas necessárias para o funcionamento da aplicação. O arquivo completo pode ser encontrado em `src/database/schema.sql`.

3. Configure o arquivo `.env` na raiz do projeto com as seguintes variáveis:
   ```env
   # Configuração obrigatória
   PORT=3001
   NODE_ENV=development
   
   # Configuração do banco de dados (obrigatória)
   DB_HOST=localhost
   DB_USER=your_mysql_user
   DB_PASSWORD=your_mysql_password
   DB_NAME=financial_app
   
   # Configuração opcional do pool de conexões
   DB_CONNECTION_LIMIT=10
   DB_QUEUE_LIMIT=0
   DB_WAIT_FOR_CONNECTIONS=true

   # Configuração do JWT (opcional)
   # Se não configurado, o sistema usará valores padrão internos
   JWT_SECRET=sua_chave_secreta_muito_segura
   JWT_EXPIRES_IN=90d
   ```



4. Inicialize o banco de dados (este comando irá executar o schema.sql):
   ```bash
   npm run init-db
   ```

5. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```

A API estará disponível em `http://localhost:3001`.

## Endpoints da API

### Autenticação

- `POST /api/v1/auth/register` - Registrar novo usuário
- `POST /api/v1/auth/login` - Login e obtenção do token de autenticação

### Categorias

- `POST /api/v1/categories` - Criar nova categoria
- `GET /api/v1/categories` - Listar todas as categorias
- `GET /api/v1/categories/:id` - Obter uma categoria específica
- `PATCH /api/v1/categories/:id` - Atualizar uma categoria
- `DELETE /api/v1/categories/:id` - Excluir uma categoria

### Contas

- `POST /api/v1/accounts` - Criar nova conta
- `GET /api/v1/accounts` - Listar todas as contas
- `GET /api/v1/accounts/:id` - Obter uma conta específica
- `PATCH /api/v1/accounts/:id` - Atualizar uma conta
- `DELETE /api/v1/accounts/:id` - Excluir uma conta
- `GET /api/v1/accounts/:id/balance` - Obter saldo atual de uma conta

### Transações

- `POST /api/v1/transactions` - Criar nova transação
- `GET /api/v1/transactions/account/:accountId` - Listar transações de uma conta
- `GET /api/v1/transactions/:id` - Obter uma transação específica
- `PATCH /api/v1/transactions/:id` - Atualizar uma transação
- `DELETE /api/v1/transactions/:id` - Excluir uma transação
- `GET /api/v1/transactions/period` - Listar transações por período

## Exemplos de Requisições/Respostas

### Registro de Usuário

Requisição:
```http
POST /api/v1/auth/register
Content-Type: application/json

{
  "email": "test@example.com",
  "password": "senhasegura123",
  "name": "Usuário Teste"
}
```

Resposta:
```json
{
  "status": "success",
  "data": {
    "user": {
      "id": 1,
      "email": "test@example.com",
      "name": "Usuário Teste"
    }
  }
}
```

### Login de Usuário

Requisição:
```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "test@example.com",
  "password": "senhasegura123"
}
```

Resposta:
```json
{
  "status": "success",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": 1,
      "email": "test@example.com",
      "name": "Usuário Teste"
    }
  }
}
```

### Autenticação para Endpoints Protegidos

Todos os endpoints, exceto `/api/v1/auth/login` e `/api/v1/auth/register`, requerem autenticação. Inclua o token JWT no cabeçalho Authorization:

```http
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Obter Saldo da Conta

Requisição:
```http
GET /api/v1/accounts/1/balance
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```